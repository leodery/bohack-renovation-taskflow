@echo off
call "%~dp0start.cmd" demo
